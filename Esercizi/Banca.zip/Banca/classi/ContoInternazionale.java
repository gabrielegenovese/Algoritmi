package classi;

public class ContoInternazionale extends ContoCorrente {
    
}
