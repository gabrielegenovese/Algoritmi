public enum Valute {
    EURO,
    DOLLARO,
    STERLINA,
    YEN
}
